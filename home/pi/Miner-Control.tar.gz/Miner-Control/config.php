<?php
/******************************************************************
*			       Configfile for your Miner					  *
*					A: Sven Goessling							  *
*					W: Miner-Control.de							  *
*						V: 1.0.0								  *
******************************************************************/
//Configuration Part Begin
	$TransactionHash = '';
	$MinerToken = '';
	$ConfigFile = '../../../home/pi/cgminer.conf';
//Configuration Part End
?>